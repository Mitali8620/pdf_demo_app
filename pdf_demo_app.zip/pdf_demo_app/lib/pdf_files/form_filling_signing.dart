import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pointycastle/asymmetric/api.dart';
import 'package:pointycastle/pointycastle.dart';

class FormFillingSigning extends StatefulWidget {
  @override
  _FormFillingSigningState createState() => _FormFillingSigningState();
}

class _FormFillingSigningState extends State<FormFillingSigning> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  bool _isSigned = false;
  Uint8List? _signatureBytes;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('PDF Form Filling and Signing'),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Text(
                'Fill out the form below:',
                style: Theme.of(context).textTheme.headline6,
              ),
              const SizedBox(height: 16.0),
              /*  PdfTextField(
                rect: PdfRect(10, 10, MediaQuery.of(context).size.width, MediaQuery.of(context).size.height),
                name: 'Name',
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Name',
                ),
                validator: (value) {
                  if (value.isEmpty) {
                    return 'Please enter your name';
                  }
                  return null;
                },
              ),*/
              const SizedBox(height: 16.0),
              /* PdfTextField(
                name: 'Email',
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                ),
                validator: (value) {
                  if (value.isEmpty) {
                    return 'Please enter your email';
                  }
                  if (!value.contains('@')) {
                    return 'Please enter a valid email';
                  }
                  return null;
                },
              ),*/
              const SizedBox(height: 16.0),
              ElevatedButton(
                child: const Text('Submit'),
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    await _createPdf();
                  }
                },
              ),
              const SizedBox(height: 16.0),
              if (_isSigned)
                Image.memory(
                  _signatureBytes!,
                  width: 200.0,
                  height: 100.0,
                ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _createPdf() async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        build: (context) => pw.Center(
          child: pw.Text(
            'PDF Form Filled and Signed',
            style: const pw.TextStyle(fontSize: 24.0),
          ),
        ),
      ),
    );

    pw.TextField(
      name: 'Name',
      value: _nameController.text,
    );

    pw.TextField(
      name: 'Email',
      value: _emailController.text,
    );
  }
}
