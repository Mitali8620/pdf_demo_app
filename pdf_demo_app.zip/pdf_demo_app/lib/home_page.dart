import 'package:flutter/material.dart';

class Homepage extends StatefulWidget {
  const Homepage({Key? key}) : super(key: key);

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Pdf implementation"),
      ),
      body: Column(
        children: [
          ElevatedButton(onPressed: () {}, child: const Text("Create pdf")),
          ElevatedButton(onPressed: () {}, child: const Text("Edit pdf")),
          ElevatedButton(onPressed: () {
            ///PdfToImageConversionPage

          }, child: const Text("Pdf to image")),
        ],
      ),
    );
  }
}
